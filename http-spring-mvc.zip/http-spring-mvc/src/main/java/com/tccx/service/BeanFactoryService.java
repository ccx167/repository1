package com.tccx.service;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.stereotype.Service;

@Service
public class BeanFactoryService<T> implements BeanFactoryAware {
	private BeanFactory beanFactory;
	
	public T getBean(String name,Class<T> requiredType) {
		return this.beanFactory.getBean(name, requiredType);
	}

	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		this.beanFactory = beanFactory;
	}
}
