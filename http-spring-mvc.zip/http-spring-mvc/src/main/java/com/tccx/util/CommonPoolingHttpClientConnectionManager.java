package com.tccx.util;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;

import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommonPoolingHttpClientConnectionManager {
	 private static Logger log = LoggerFactory.getLogger(CommonPoolingHttpClientConnectionManager.class);
	private CommonPoolingHttpClientConnectionManager(){}
	
	
	public static PoolingHttpClientConnectionManager createPoolingHttpClientConnectionManager(int maxTotal,int defaultMaxPerRoute){
		//需要通过以下代码声明对https连接支持  
		   SSLContext sslcontext;
		try {
			sslcontext = SSLContexts.custom().loadTrustMaterial(null,  
			                   new TrustSelfSignedStrategy())  
			           .build();
		
		   HostnameVerifier hostnameVerifier = SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;  
		   SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(  
		           sslcontext,hostnameVerifier);  
		   Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()  
		           .register("http", PlainConnectionSocketFactory.getSocketFactory())  
		           .register("https", sslsf)  
		           .build();  
		   //初始化连接管理器  
		   PoolingHttpClientConnectionManager poolConnManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);   
		   poolConnManager.setMaxTotal(maxTotal);
		   poolConnManager.setDefaultMaxPerRoute(defaultMaxPerRoute);
		   return poolConnManager;
		} catch (Exception e) {
			log.error("",e);
		}  
		return null;
	         
	}
	
	public static PoolingHttpClientConnectionManager createGZTPoolingHttpClientConnectionManager(int maxTotal,int defaultMaxPerRoute,int validateAfterInactivity){
		//需要通过以下代码声明对https连接支持  
		   SSLContext sslcontext;
		try {
			sslcontext = SSLContexts.custom().loadTrustMaterial(null,  
			                   new TrustSelfSignedStrategy())  
			           .build();
		
		   HostnameVerifier hostnameVerifier = SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER;  
		   SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(  
		           sslcontext,hostnameVerifier);  
		   Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()  
		           .register("http", PlainConnectionSocketFactory.getSocketFactory())  
		           .register("https", sslsf)  
		           .build();  
		   //初始化连接管理器  
		   PoolingHttpClientConnectionManager poolConnManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);   
		   poolConnManager.setMaxTotal(maxTotal);
		   poolConnManager.setDefaultMaxPerRoute(defaultMaxPerRoute);
		   poolConnManager.setValidateAfterInactivity(validateAfterInactivity);
		   return poolConnManager;
		} catch (Exception e) {
			log.error("",e);
		}  
		return null;
	         
	}

}
