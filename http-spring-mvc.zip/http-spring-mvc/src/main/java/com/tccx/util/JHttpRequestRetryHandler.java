package com.tccx.util;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;

import org.apache.commons.logging.Log;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpRequest;
import org.apache.http.NoHttpResponseException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.protocol.HttpContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class JHttpRequestRetryHandler implements HttpRequestRetryHandler{
	 private static Logger log = LoggerFactory.getLogger(JHttpRequestRetryHandler.class);
	private JHttpRequestRetryHandler () {}
	
	public  boolean retryRequest(IOException exception,
			int executionCount, HttpContext context) {
		if (executionCount >= 3) {// 如果已经重试了3次，就放弃
			log.info("-------------重试3.1----------"+executionCount+"---------",exception);
			return false;
		}
		int i=0;
		Boolean test=false;
		if (exception instanceof NoHttpResponseException) {// 如果服务器丢掉了连接，那么就重试
			i=1;
			test= true;
		}
		if (exception instanceof SSLHandshakeException) {// 不要重试SSL握手异常
			i=2;
			test=false;
		}
		if (exception instanceof InterruptedIOException) {// 超时
			i=3;
			test=false;
		}
		if (exception instanceof UnknownHostException) {// 目标服务器不可达
			i=4;
			test=false;
		}
		if (exception instanceof ConnectTimeoutException) {// 连接被拒绝
			i=5;
			test= false;
		}
		if (exception instanceof SSLException) {// ssl握手异常
			i=6;
			test=false;
		}
		HttpClientContext clientContext = HttpClientContext.adapt(context);
		HttpRequest request = clientContext.getRequest();
/*		// 如果请求是幂等的，就再次尝试
		if (!(request instanceof HttpEntityEnclosingRequest)) {
			test=true;
		}*/
		log.info("--------------i----------"+i+"------test----------"+test);
		return test;
	}
		
	}
