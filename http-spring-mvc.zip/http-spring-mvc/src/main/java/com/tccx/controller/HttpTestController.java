package com.tccx.controller;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;
import com.tccx.service.BeanFactoryService;

@Controller
@RequestMapping("/http")
public class HttpTestController {

	@Autowired
	private BeanFactoryService<HttpClient> beanFactoryService;// 引入BeanFactoryService
	
	@ResponseBody
	@RequestMapping("/testCon")
	public String httpTest(String tid) {
		JsonObject totalJsonObj = new JsonObject();
		totalJsonObj.addProperty("tid", tid);
		StopWatch totalWatch = new StopWatch();
		totalWatch.start();
		String url ="http://192.168.0.118:8880/http-spring-mvc/person/http";
		HttpClient httpClient = beanFactoryService.getBean("viewCloseableHttpClient", HttpClient.class);
		String sendHttpPostRequest = executePostForView(httpClient, url, totalJsonObj.toString());
		totalWatch.stop();
		String ret = tid+sendHttpPostRequest;
		System.out.println(ret);
		return ret;
		//return "哈哈"+tid;
	}
	
	public String executePostForView(HttpClient httpClient, String url, String json) {
		String resultStr = null;
		HttpPost httpPost = new HttpPost(url);
		httpPost.setHeader("Content-Type", "text/html;charset=UTF-8");
		try {
			StringEntity s = new StringEntity(json, "utf-8");
			s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
			httpPost.setEntity(s);
			// 发送请求
			HttpResponse httpResponse = httpClient.execute(httpPost);
			if (httpResponse != null) {
				if (httpResponse.getStatusLine() != null) {
					int statusCode = httpResponse.getStatusLine().getStatusCode();
				//	System.out.println(">>>ViewhttpClient, status code: "+statusCode);
					if (statusCode == 200) {
						resultStr = EntityUtils.toString(httpResponse.getEntity(), "utf-8");
					//	System.out.println("正常返回****"+resultStr);
					}
				}
			}
		} catch (Exception e) {		
			resultStr = e.getMessage();
		//	System.out.println("异常喽****"+resultStr);
		} finally {
			// 释放连接
			httpPost.releaseConnection();
		}
		return resultStr;
	}

}
