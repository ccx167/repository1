package com.tccx.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/person")
public class PersonController {
	@ResponseBody
	@RequestMapping(value = "/http", method = RequestMethod.POST)
	public String test(String tid) {
		System.out.println("tid:" + tid + "进入 /person/http入口");
		try {
			Thread.sleep(3200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		
		}
		return  "tid:" + tid + "睡了3.2秒";
	}

}
