package com.text.ccx;

import java.io.File;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;

public class UploadFile {

	private static final String URL_STR = "http://127.0.0.1:8080/data-service/uploadFile";

	public static void main(String[] args) {
		String localFile = "D:/test/mveness.txt";
		File file = new File(localFile);
		System.out.println(file.exists());
		file.deleteOnExit();
		boolean del = file.delete();
		System.out.println(del);
		//upload(localFile);
	}

	public static void upload(String localFile) {
		File file = new File(localFile);
		PostMethod filePost = new PostMethod(URL_STR);
		HttpClient client = new HttpClient();

		try {
			// 通过以下方法可以模拟页面参数提交
			/*
			 * filePost.setParameter("userName", userName);
			 * filePost.setParameter("passwd", passwd);
			 */

			Part[] parts = { new FilePart(file.getName(), file) };
			filePost.setRequestEntity(new MultipartRequestEntity(parts, filePost.getParams()));

			client.getHttpConnectionManager().getParams().setConnectionTimeout(5000);

			int status = client.executeMethod(filePost);
			if (status == HttpStatus.SC_OK) {
				System.out.println("上传成功");
			} else {
				System.out.println("上传失败");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			filePost.releaseConnection();
		}
	}

}
