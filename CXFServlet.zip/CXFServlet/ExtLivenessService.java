package com.ccx.credit.data.external.rest.servlet;

import com.ccx.credit.data.external.ds.HistoryService;
import com.ccx.credit.data.external.interfaces.IChargeService;
import com.ccx.credit.data.shared.charge.PreCheckResult;
import com.ccx.credit.data.shared.db.dto.pccredit.ZxUserHistory;
import com.ccx.credit.data.shared.enumeration.CidType;
import com.ccx.credit.data.shared.enumeration.returncode.ChargeType;
import com.ccx.credit.data.shared.util.*;
import com.ccx.dp.common.enums.constants.HistoryType;
import com.ccx.dp.common.enums.constants.ResCode;
import com.ccx.dp.common.model.liveness.RspLivenessInfo;

import com.ccx.dp.common.model.livenessCheck.DsRspSetLivenessInfo;
import com.ccx.dp.common.model.set.VerificationScore;
import com.ccx.dp.common.service.set.RpcCheckLivenessService;
import com.google.gson.Gson;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang3.time.StopWatch;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.PhaseInterceptorChain;
import org.apache.cxf.transport.http.AbstractHTTPDestination;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

@Path("/identity")
public class ExtLivenessService {
	private static Logger log = LoggerFactory.getLogger(ExtLivenessService.class);

	@Autowired
	private IChargeService chargeService;

	@Autowired
	private HistoryService historyService;

	@Autowired
	private RpcCheckLivenessService rpcCheckLivenessService;

	/**
	 * 活检入口
	 */
	@POST
	@Path("/facedetect4")
	@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
	public RspLivenessInfo queryLivenessIdnumber(@QueryParam("account") String account,
			@QueryParam("reqTid") String reqTid, @QueryParam("sign") String sign, @QueryParam("name") String name,
			@QueryParam("idnumber") String idnumber, @QueryParam("auto_rotate") String auto_rotate) {
		log.info("******活体检验-综合验证-begin*******");
		log.info("********/identity/facedetect4*********");
		RspLivenessInfo response = new RspLivenessInfo();
		String resCode = ResCode.RC_INTERNAL_ERR.getCode();
		String resMsg = ResCode.RC_INTERNAL_ERR.getName();
		response.setResCode(resCode);
		response.setResMsg(resMsg);
		StopWatch sw = new StopWatch();
		sw.start();
		log.info("account:{}", account);
		log.info("reqTid:{}", reqTid);
		log.info("sign:{}", sign);
		log.info("idnumber:{}", idnumber);
		log.info("name:{}", name);
		String entityString = null;
		// 检验参数
		if (!ServiceUtil.verifyParams(account, reqTid, sign, idnumber, name) || reqTid.length() > 32) {
			log.debug("request info is missing.");
			response.setResCode(ResCode.RC_ERR_PARAM_FORMAT.getCode());
			response.setResMsg(ResCode.RC_ERR_PARAM_FORMAT.getName());
			return response;
		}
		// 身份证号码校验
		String idValid = IDCardValid.IDCardValidate(idnumber);
		if (idValid == null || !idValid.equals("true")) {
			log.info("身份证号验证失败...");
			response.setResCode(ResCode.RC_ERR_PARAM_FORMAT.getCode());
			response.setResMsg(ResCode.RC_ERR_PARAM_FORMAT.getName());
			entityString = new Gson().toJson(response);
			log.info("response content:{}", entityString);
			return response;
		}
		if (!ServiceUtil.verifyParamsForName(name)) {
			log.info("姓名验证失败...");
			response.setResCode(ResCode.RC_ERR_PARAM_FORMAT.getCode());
			response.setResMsg(ResCode.RC_ERR_PARAM_FORMAT.getName());
			entityString = new Gson().toJson(response);
			log.info("response content: {}", entityString);
			return response;
		}
		// 创建zxUserHistory
		log.info("==========2. create zxUserHistory===========");
		ZxUserHistory zxUserHistory = new ZxUserHistory();

		HistoryType ht = HistoryType.HT_IDENTITY_LIVE_ID;// 更改对应数据源
		String tid = TidUtil.genTid(ht);
		response.setReqTid(reqTid);
		response.setTid(tid);
		zxUserHistory.setAccount(account);
		zxUserHistory.setCid(idnumber);
		boolean charge = false;
		boolean chargeState = false;
		zxUserHistory.setChargeState(chargeState);
		zxUserHistory.setCharge(charge);
		zxUserHistory.setCidType(CidType.CT_IDENTITY_CARD.getIndex());
		zxUserHistory.setType(ht.getIndex());
		zxUserHistory.setEmail(CxfUtil.getRemoteIPAddr());
		// 预检查
		log.info("=========3.pre-check==========");
		Map<String, String> signMap = new HashMap<>();
		signMap.put("reqTid", reqTid);
		signMap.put("account", account);
		signMap.put("name", name);
		signMap.put("idnumber", idnumber);

		PreCheckResult preCheckResult = chargeService.preCheck(account, ht, null, signMap, sign);
		double price = preCheckResult.getPrice();
		String privateKey = preCheckResult.getPrivateKey();
		ResCode preCheckResCode = preCheckResult.getResCode();
		ChargeType ct = preCheckResult.getCt();
		// 预检查不通过
		if (!ResCode.RC_PRE_CHECK_PASS.equals(preCheckResCode)) {
			// preCheck 不通过
			resCode = preCheckResCode.getCode();
			resMsg = preCheckResCode.getName();

			// 生成返回签名
			Map<String, String> rspSignMap = new TreeMap<String, String>();
			rspSignMap.put("resCode", resCode);
			rspSignMap.put("reqTid", reqTid);
			rspSignMap.put("tid", tid);

			String rspSign = SignUtil.genSignedString(rspSignMap, privateKey);
			log.debug("the rsp sign: {}", rspSign);

			response.setResCode(resCode);
			response.setResMsg(resMsg);
			response.setReqTid(reqTid);
			response.setTid(tid);
			response.setSign(rspSign);

			try {
				entityString = new Gson().toJson(response);
			} catch (Exception e) {
				log.error("rsponse Exception: ", e);
			}

			log.info(">>> pre-check failed result:{} ", entityString);

			log.info("=====save history====");
			zxUserHistory.setHistoryData(entityString);
			zxUserHistory.setResult(response.getResCode());

			sw.stop();
			log.info("the total spend time: {}", sw.getTime());
			zxUserHistory.setSpent(String.valueOf(sw.getTime()));
			String zxhStr = new Gson().toJson(zxUserHistory);
			log.debug("the zxh history: {}", zxhStr);

			historyService.saveUserHistory(zxUserHistory);
			return response;
		}
		sw.stop();
		log.info("precheck spent time: {}", sw);
		
		File liveness_file = null;
		try {
			liveness_file = getClientInfoCxf();
		} catch (Exception e) {
			return response;
		}

		// 2> query data ds
		// 预检查通过，访问数据源
		log.info("reqTid：{}, tid:{}------strart query ds checkLiveness--------", reqTid, tid);
		sw.reset();
		sw.start();

		DsRspSetLivenessInfo dsRspSetLivenessInfo = rpcCheckLivenessService.checkLiveness(account, name, idnumber, tid,
				liveness_file, Boolean.parseBoolean(auto_rotate));
		log.info("reqTid:{},tid:{}------end query ds  checkLiveness, result:{}--------", reqTid, tid,
				dsRspSetLivenessInfo);
		if(liveness_file != null && liveness_file.exists()){
			liveness_file.delete(); //业务处理完毕删除临时文件
		}
		VerificationScore verificationScore = dsRspSetLivenessInfo.getVerificationScore();
		response.setResMsg(dsRspSetLivenessInfo.getResMsg());
		response.setResCode(dsRspSetLivenessInfo.getResCode());
		response.setData(verificationScore);
		// 返回数据
		response.setSign(SignUtil.sign(ResCode.getEnum(response.getResCode()), tid, privateKey));
		charge = dsRspSetLivenessInfo.isCharge();
		zxUserHistory.setCharge(charge);
		if (charge) {
			chargeState = chargeService.chargeAll(account, price, ct, ht);
			zxUserHistory.setChargeState(chargeState);
			zxUserHistory.setExpense(price);
		}
		// 保存记录
		entityString = new Gson().toJson(response);
		log.info("response content:{}", entityString);
		zxUserHistory.setResult(response.getResCode());
		zxUserHistory.setHistoryData(entityString);
		sw.stop();
		zxUserHistory.setSpent(String.valueOf(sw.getTime()));
		historyService.saveUserHistory(zxUserHistory);

		// 4> return result
		log.info("综合验证消耗时间:{}", sw);
		log.info("************综合验证-end**************");
		return response;
	}

	private File getClientInfoCxf() {
		log.info(">>>>>>>>>>remote info<<<<<<<<<");
		File liveness_file = null;
		try {
			Message message = PhaseInterceptorChain.getCurrentMessage();
			HttpServletRequest request = (HttpServletRequest) message.get(AbstractHTTPDestination.HTTP_REQUEST);
			DiskFileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload fileUpload = new ServletFileUpload(factory);
			List<FileItem> formItems = fileUpload.parseRequest(request);
			for (FileItem item : formItems) {
				String filename = item.getName();
				log.info("file name:{}", filename);
				liveness_file = new File(File.separator + "opt" + File.separator + "data-service" + File.separator
						+ "liveness_file" + File.separator + filename);
				if (!liveness_file.exists()) {
					liveness_file.createNewFile();
				}
				item.write(liveness_file);
			}
		} catch (Exception e) {
			log.error("get upload file error...", e);
			throw new RuntimeException();
		}
		return liveness_file;
	}

}
