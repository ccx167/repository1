package com.study.boot.service;

import com.study.boot.dao.PersonDao;
import com.study.boot.model.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonService {

    @Autowired
    PersonDao personDao;

    public Person selectUserById(int id){
        return  personDao.selectByPrimaryKey(id);
    }
}
