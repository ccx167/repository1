package com.study.boot.controller;

import com.study.boot.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PersonController {

    @Autowired
    public PersonService personService;

    @RequestMapping("/showUser")
    public  String selectUserById(int id){
       System.out.println("*************哈哈**********************************"+id);
        return  personService.selectUserById(id).toString();
    }
}
