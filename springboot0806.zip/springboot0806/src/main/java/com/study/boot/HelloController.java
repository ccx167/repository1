package com.study.boot;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController<main> {

    @RequestMapping("/hello")
    public String sayHello() {
        return "hello word, 人头马!";
    }

}
